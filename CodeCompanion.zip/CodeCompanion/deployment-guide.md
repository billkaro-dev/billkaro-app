# InvoiceGen Deployment Guide

This guide will help you deploy the InvoiceGen application on your own web server.

## Prerequisites

Your server should have:
- Node.js (version 18 or higher)
- npm (version 8 or higher)

## Deployment Steps

### 1. Extract the Files

First, extract the `invoice-generator.zip` file to your desired location on your server.

```
unzip invoice-generator.zip -d invoice-generator
cd invoice-generator
```

### 2. Install Dependencies

Install all the required dependencies:

```
npm install
```

### 3. Build the Application

Build the application for production:

```
npm run build
```

This will create optimized production files in the `dist` directory.

### 4. Start the Application

There are two ways to run the application:

#### Option 1: Direct Node.js Execution (for testing)

```
NODE_ENV=production node dist/server/index.js
```

#### Option 2: Using Process Manager (recommended for production)

Install PM2 (a production process manager for Node.js):

```
npm install -g pm2
```

Start the application with PM2:

```
pm2 start dist/server/index.js --name invoice-generator
```

PM2 Commands:
- Stop the app: `pm2 stop invoice-generator`
- Restart the app: `pm2 restart invoice-generator`
- View logs: `pm2 logs invoice-generator`
- Make app start on server boot: `pm2 startup` and follow instructions

### 5. Configuring a Web Server (Optional but Recommended)

For production environments, it's recommended to use a web server like Nginx or Apache as a reverse proxy.

#### Nginx Configuration Example

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### Apache Configuration Example

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com

    ProxyRequests Off
    ProxyPreserveHost On
    ProxyVia Full

    <Proxy *>
        Require all granted
    </Proxy>

    ProxyPass / http://localhost:5000/
    ProxyPassReverse / http://localhost:5000/
</VirtualHost>
```

Enable the necessary Apache modules:
```
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo systemctl restart apache2
```

### 6. Setting Up SSL/HTTPS (Recommended)

For a production site, you should secure your application with SSL. You can use Let's Encrypt to get a free SSL certificate.

#### Using Certbot with Nginx:

```
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

#### Using Certbot with Apache:

```
sudo apt-get install certbot python3-certbot-apache
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com
```

## Troubleshooting

1. **Port Issues**: If port 5000 is already in use, you can change it in `server/index.ts` before building, or set the PORT environment variable when running:
   ```
   PORT=3000 NODE_ENV=production node dist/server/index.js
   ```

2. **Permission Issues**: Make sure your user has appropriate permissions to the project directory.

3. **Database**: The application uses an in-memory database by default. If you want to use a persistent database, you'll need to modify the storage implementation.

## Maintenance

- Keep Node.js and npm up to date
- Regularly update the application dependencies with `npm update`
- Monitor the application logs for any errors
- Set up regular backups if you implement a persistent database

## Need Help?

If you encounter any issues during deployment, please check:
- Node.js and npm versions
- Server logs
- Network/firewall settings
- File permissions