# Deploying InvoiceGen on Hostinger

This guide provides detailed instructions for deploying the InvoiceGen application on Hostinger web hosting.

## Prerequisites

1. A Hostinger web hosting account
2. Access to Hostinger control panel
3. Basic understanding of FTP or file uploads

## Deployment Steps

### Step 1: Prepare Your Hostinger Account

1. **Log in to your Hostinger account** and access the control panel.
2. **Create a new website** or select an existing one where you want to deploy InvoiceGen.

### Step 2: Set Up Node.js on Hostinger

Hostinger supports Node.js applications through their Premium and Business hosting plans. Here's how to set it up:

1. In your Hostinger control panel, go to **Website** > **Other** > **Node.js**.
2. Click on **Install Node.js**.
3. Choose the latest stable Node.js version (14.x or higher).
4. Note the **Node.js application URL** that Hostinger provides.

### Step 3: Upload the Application Files

You have two options for uploading files:

#### Option A: Using File Manager

1. In your Hostinger control panel, go to **Files** > **File Manager**.
2. Navigate to the **public_html** directory or your designated Node.js application directory.
3. Click **Upload** and select the `invoice-generator.zip` file.
4. After upload, right-click the zip file and select **Extract**.

#### Option B: Using FTP (Recommended for larger files)

1. Use an FTP client (like FileZilla) with your Hostinger FTP credentials.
2. Connect to your hosting account and navigate to the **public_html** directory.
3. Upload the `invoice-generator.zip` file.
4. Extract the ZIP file on the server.

### Step 4: Configure the Application

1. Using File Manager or FTP, navigate to the extracted application folder.
2. Locate and edit the `server/index.ts` file before building.
3. Make sure the server listens on the port provided by Hostinger:

   ```typescript
   // Find this section in server/index.ts
   const PORT = process.env.PORT || 5000;
   // No changes needed if it's already like this
   ```

4. If using Hostinger's Node.js environment, create a new file named `start.js` in the root directory with this content:

   ```javascript
   import { spawn } from 'child_process';
   
   // Start the Node.js application
   const app = spawn('node', ['dist/server/index.js'], { 
     env: { ...process.env, PORT: process.env.PORT || 8080 } 
   });
   
   app.stdout.on('data', (data) => {
     console.log(`stdout: ${data}`);
   });
   
   app.stderr.on('data', (data) => {
     console.error(`stderr: ${data}`);
   });
   
   app.on('close', (code) => {
     console.log(`child process exited with code ${code}`);
   });
   ```

### Step 5: Install Dependencies and Build

Hostinger allows you to use SSH or run commands through their Terminal:

1. In your Hostinger control panel, go to **Advanced** > **SSH Access** or **Terminal**.
2. Navigate to your application directory:
   ```
   cd ~/public_html/your-app-directory
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Build the application:
   ```
   npm run build
   ```

### Step 6: Set Up Application in Node.js Manager

1. Go back to the Node.js section in your Hostinger control panel.
2. Click on **Create a New Application**.
3. Fill in the following details:
   - **Application name**: InvoiceGen
   - **Application startup file**: start.js
   - **Application URL**: Choose your preferred URL (e.g., invoicegen.yourdomain.com)
4. Click **Save** to create the application.

### Step 7: Start Your Application

1. In the Node.js manager, find your InvoiceGen application.
2. Click the **Start** button to launch your application.
3. Your application should now be running at the URL you specified.

### Step 8: Set Up Domain and SSL

1. If you haven't already, go to **Domains** > **Manage** to set up your domain.
2. To enable SSL, go to **SSL** > **Setup** and follow the instructions for obtaining a free Let's Encrypt SSL certificate.

## Troubleshooting Common Issues

### Issue: Application doesn't start
- Check the logs in the Node.js manager
- Verify that all dependencies are installed correctly
- Ensure the port configuration matches Hostinger's requirements

### Issue: "502 Bad Gateway" error
- The application might be crashing; check the application logs
- Ensure that the Node.js version is compatible with your code
- Check if your application is exceeding the allocated memory limits

### Issue: Static files not loading
- Make sure the path to static files in `server/vite.ts` is correct
- Verify that the build process completed successfully

### Issue: Database connection problems
- If you plan to use a database, make sure to update connection strings to use Hostinger's MySQL database
- Create the necessary database user and permissions in Hostinger's control panel

## Performance Optimization for Hostinger

1. **Enable Gzip Compression**:
   - Create or edit `.htaccess` file in your public directory:
     ```
     <IfModule mod_deflate.c>
       AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
     </IfModule>
     ```

2. **Set up browser caching**:
   - Add to `.htaccess`:
     ```
     <IfModule mod_expires.c>
       ExpiresActive On
       ExpiresByType image/jpg "access plus 1 year"
       ExpiresByType image/jpeg "access plus 1 year"
       ExpiresByType image/gif "access plus 1 year"
       ExpiresByType image/png "access plus 1 year"
       ExpiresByType image/svg+xml "access plus 1 year"
       ExpiresByType text/css "access plus 1 month"
       ExpiresByType application/pdf "access plus 1 month"
       ExpiresByType text/javascript "access plus 1 month"
       ExpiresByType application/javascript "access plus 1 month"
       ExpiresByType application/x-javascript "access plus 1 month"
       ExpiresByType application/x-shockwave-flash "access plus 1 month"
       ExpiresByType image/x-icon "access plus 1 year"
       ExpiresDefault "access plus 2 days"
     </IfModule>
     ```

## Maintenance and Updates

1. When updating your application:
   - Upload the new version via FTP or File Manager
   - Run `npm install` and `npm run build` again
   - Restart the application in the Node.js manager

2. Monitor your application:
   - Regularly check logs for errors
   - Set up monitoring for uptime and performance

## Need Help?

If you encounter issues specific to Hostinger, their customer support is available 24/7 through their live chat or support ticket system.