import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, FileText, Download, DollarSign, Globe, Shield, HelpCircle, BookOpen } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import logo from "../assets/logo.svg";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <div className="mb-6">
                <Logo size="lg" />
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-5">Free Professional Invoice Generator</h2>
              <p className="text-xl text-gray-600 mb-8">
                Create customizable, professional invoices in minutes. No hidden fees, no limitations.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/invoice/create">
                  <Button size="lg" className="text-base px-6">
                    Create New Invoice
                  </Button>
                </Link>
                <Link href="/guide">
                  <Button size="lg" variant="outline" className="text-base px-6">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="bg-gray-100 rounded-xl p-8 shadow-md">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <Logo size="sm" showText={false} />
                    <span className="font-semibold">Invoice Preview</span>
                  </div>
                  <span className="text-sm text-gray-500">INV-2025-001</span>
                </div>
                <div className="space-y-3 mb-4">
                  <div className="h-4 bg-gray-300 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-300 rounded w-1/4"></div>
                </div>
                <div className="mt-6 space-y-2">
                  <div className="flex justify-between pb-2 border-b border-gray-200">
                    <div className="h-4 bg-gray-300 rounded w-1/3"></div>
                    <div className="h-4 bg-gray-300 rounded w-1/6"></div>
                  </div>
                  <div className="flex justify-between pb-2 border-b border-gray-200">
                    <div className="h-4 bg-gray-300 rounded w-1/3"></div>
                    <div className="h-4 bg-gray-300 rounded w-1/6"></div>
                  </div>
                  <div className="flex justify-between pb-2 border-b border-gray-200">
                    <div className="h-4 bg-gray-300 rounded w-1/3"></div>
                    <div className="h-4 bg-gray-300 rounded w-1/6"></div>
                  </div>
                </div>
                <div className="mt-6 flex justify-end">
                  <div className="h-8 bg-gray-300 rounded w-1/4"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-3">Why Choose Our Free Invoice Generator?</h2>
          <p className="text-xl text-center text-gray-600 max-w-3xl mx-auto">
            InvoiceGen provides a completely free invoice generator that helps freelancers, small businesses, and professionals create professional-looking invoices in minutes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="mr-2 h-5 w-5 text-primary" />
                Instant PDF Download
              </CardTitle>
              <CardDescription>
                Generate and download professional PDF invoices with a single click
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="mr-2 h-5 w-5 text-primary" />
                Multiple Payment Options
              </CardTitle>
              <CardDescription>
                Support for bank transfers, PayPal, UPI, and custom payment links
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="mr-2 h-5 w-5 text-primary" />
                Currency Support
              </CardTitle>
              <CardDescription>
                Create invoices in any currency with automatic formatting
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="mr-2 h-5 w-5 text-primary" />
                100% Free Forever
              </CardTitle>
              <CardDescription>
                No hidden costs or premium features; everything is accessible to everyone
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <HelpCircle className="mr-2 h-5 w-5 text-primary" />
                Easy to Use
              </CardTitle>
              <CardDescription>
                No sign-up required - start creating invoices immediately
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="mr-2 h-5 w-5 text-primary" />
                Comprehensive Guide
              </CardTitle>
              <CardDescription>
                Access our detailed invoice guide to create perfect invoices
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/guide">
                <Button variant="outline" size="sm">
                  View Guide
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-6">Ready to Create Your Invoice?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PlusCircle className="mr-2 h-5 w-5" />
                  Create Invoice
                </CardTitle>
                <CardDescription>
                  Create a new professional invoice
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/invoice/create">
                  <Button className="w-full">
                    Create New Invoice
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  View Invoices
                </CardTitle>
                <CardDescription>
                  Manage your existing invoices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/invoice/list">
                  <Button className="w-full" variant="outline">
                    View All Invoices
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-100 border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <Logo size="sm" />
            </div>
            <div className="flex space-x-6">
              <Link href="/guide">
                <span className="text-gray-600 hover:text-gray-900">Guide</span>
              </Link>
              <Link href="/invoice/create">
                <span className="text-gray-600 hover:text-gray-900">Create Invoice</span>
              </Link>
              <Link href="/invoice/list">
                <span className="text-gray-600 hover:text-gray-900">View Invoices</span>
              </Link>
            </div>
          </div>
          <div className="mt-4 text-center md:text-right text-sm text-gray-500">
            © {new Date().getFullYear()} InvoiceGen. All rights reserved.
          </div>
        </div>
      </div>
    </div>
  );
}
