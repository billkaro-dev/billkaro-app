import { useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { InvoiceForm } from "@/components/invoice/invoice-form";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { InsertInvoice } from "@shared/schema";

export default function CreateInvoice() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createInvoiceMutation = useMutation({
    mutationFn: async (data: InsertInvoice) => {
      const res = await apiRequest("POST", "/api/invoices", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Invoice created",
        description: "Your invoice has been created successfully.",
      });
      navigate("/invoice/list");
    },
    onError: (error) => {
      toast({
        title: "Error creating invoice",
        description: error.message || "There was an error creating your invoice. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateInvoice = async (data: InsertInvoice) => {
    createInvoiceMutation.mutate(data);
  };

  const handleCancel = () => {
    navigate("/");
  };

  return (
    <div className="bg-gray-50 font-sans text-gray-800 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h1 className="text-2xl font-semibold text-gray-900 mb-6">Create New Invoice</h1>
        
        <InvoiceForm 
          onSubmit={handleCreateInvoice} 
          onCancel={handleCancel}
          isSubmitting={createInvoiceMutation.isPending}
        />
      </div>
    </div>
  );
}
