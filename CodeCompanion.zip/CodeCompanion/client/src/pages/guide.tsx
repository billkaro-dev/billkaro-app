import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";
import { ArrowLeft } from "lucide-react";
import { NavHeader } from "@/components/ui/nav-header";

export default function Guide() {
  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <NavHeader />
    
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Invoice Guide & Help</h1>
          <p className="text-lg text-gray-600 max-w-3xl">
            Everything you need to know about creating professional invoices and using our invoice generator.
          </p>
        </div>

        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Getting Started</h2>
          <p className="mb-4">
            Creating professional invoices is easy with our invoice generator. Just follow these simple steps:
          </p>
          <ol className="list-decimal pl-5 space-y-2 mb-6">
            <li>Click on <span className="font-medium">Create New Invoice</span> from the homepage</li>
            <li>Fill in your business information and logo</li>
            <li>Add your client's details</li>
            <li>Add invoice items with descriptions, quantities, and prices</li>
            <li>Set tax rates, discounts, and payment terms if needed</li>
            <li>Preview your invoice and download it as a PDF</li>
          </ol>
          <p>
            Your invoice will be saved automatically, and you can access it anytime from the <span className="font-medium">View All Invoices</span> page.
          </p>
        </div>

        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Invoice Basics</h2>
          <p className="mb-4">
            A professional invoice should include these key elements:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Business Information</h3>
              <p className="text-gray-600">
                Your business name, address, contact details, and optionally your logo and business number
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Client Information</h3>
              <p className="text-gray-600">
                Your client's name, address, and contact information
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Invoice Details</h3>
              <p className="text-gray-600">
                Invoice number, issue date, due date, and payment terms
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Line Items</h3>
              <p className="text-gray-600">
                Detailed description of products or services, quantities, rates, and amounts
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Totals</h3>
              <p className="text-gray-600">
                Subtotal, tax, discounts, and final amount due
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded">
              <h3 className="font-medium text-gray-900 mb-2">Payment Information</h3>
              <p className="text-gray-600">
                Payment methods, bank details, and any additional payment instructions
              </p>
            </div>
          </div>
          <p>
            Our invoice generator simplifies this process by providing all these sections in an easy-to-use form.
          </p>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>How are my invoices stored?</AccordionTrigger>
              <AccordionContent>
                Your invoices are stored securely in our system. You can access them anytime by visiting the "View All Invoices" page. No need to create an account - everything is accessible right away.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>Can I customize the invoice design?</AccordionTrigger>
              <AccordionContent>
                Yes, you can add your business logo and customize various elements like currency, payment terms, and more. The generated PDFs follow a professional, clean design that works well for business invoices.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>How do I calculate taxes on my invoice?</AccordionTrigger>
              <AccordionContent>
                Our invoice generator allows you to add tax rates easily. You can specify a percentage, and the system will automatically calculate the tax amount based on your subtotal. You can also choose whether the tax applies before or after any discounts.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger>Can I send invoices directly from the app?</AccordionTrigger>
              <AccordionContent>
                Currently, you can download your invoice as a PDF file, which you can then attach to an email to send to your clients. We're working on adding direct email functionality in future updates.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger>Is there a limit to how many invoices I can create?</AccordionTrigger>
              <AccordionContent>
                No, you can create an unlimited number of invoices with our free invoice generator. There are no restrictions or hidden fees.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger>How do I add multiple items to an invoice?</AccordionTrigger>
              <AccordionContent>
                When creating an invoice, you'll find an "Add Item" button in the line items section. Click it to add as many items as you need. Each item can have its own description, quantity, price, and amount.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-4">Ready to create your first invoice?</p>
          <Link href="/invoice/create">
            <Button size="lg">
              Create New Invoice
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}