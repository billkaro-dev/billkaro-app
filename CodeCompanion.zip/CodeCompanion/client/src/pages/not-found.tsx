import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Home, FileText } from "lucide-react";
import { Link } from "wouter";
import { Logo } from "@/components/ui/logo";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="mb-10">
        <Logo size="lg" />
      </div>
      
      <Card className="w-full max-w-md mx-4 shadow-lg">
        <CardContent className="pt-6 pb-8">
          <div className="flex flex-col items-center text-center mb-6">
            <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
            <h1 className="text-3xl font-bold text-gray-900">Page Not Found</h1>
            <p className="mt-2 text-gray-600">
              Sorry, the page you are looking for doesn't exist or has been moved.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/">
              <Button className="w-full sm:w-auto">
                <Home className="mr-2 h-4 w-4" />
                Go to Home
              </Button>
            </Link>
            <Link href="/invoice/create">
              <Button variant="outline" className="w-full sm:w-auto">
                <FileText className="mr-2 h-4 w-4" />
                Create Invoice
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
      
      <p className="mt-8 text-sm text-gray-500">
        Need help? Check our <Link href="/guide"><a className="text-primary hover:underline">Invoice Guide</a></Link>
      </p>
    </div>
  );
}
