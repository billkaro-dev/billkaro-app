import { Link, useLocation } from "wouter";
import { Logo } from "@/components/ui/logo";
import { Home, FileText, HelpCircle, FileBarChart } from "lucide-react";

export function NavHeader() {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  return (
    <header className="border-b bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 justify-between items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <Logo size="sm" />
            </div>
          </Link>
          <nav className="flex space-x-6 items-center">
            <Link href="/">
              <span className={`${isActive('/') ? 'text-primary font-medium' : 'text-gray-600 hover:text-gray-900'} flex items-center gap-1`}>
                <Home className="h-4 w-4" />
                <span className="hidden sm:inline">Home</span>
              </span>
            </Link>
            <Link href="/invoice/create">
              <span className={`${isActive('/invoice/create') ? 'text-primary font-medium' : 'text-gray-600 hover:text-gray-900'} flex items-center gap-1`}>
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">Create Invoice</span>
              </span>
            </Link>
            <Link href="/invoice/list">
              <span className={`${isActive('/invoice/list') ? 'text-primary font-medium' : 'text-gray-600 hover:text-gray-900'} flex items-center gap-1`}>
                <FileBarChart className="h-4 w-4" />
                <span className="hidden sm:inline">View Invoices</span>
              </span>
            </Link>
            <Link href="/guide">
              <span className={`${isActive('/guide') ? 'text-primary font-medium' : 'text-gray-600 hover:text-gray-900'} flex items-center gap-1`}>
                <HelpCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Guide</span>
              </span>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}