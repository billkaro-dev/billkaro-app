import logo from "../../assets/logo.svg";
import { cn } from "@/lib/utils";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export function Logo({ size = "md", showText = true, className }: LogoProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-14 w-14"
  };

  return (
    <div className={cn("flex items-center", className)}>
      <img 
        src={logo} 
        alt="InvoiceGen Logo" 
        className={cn(sizeClasses[size], "mr-2")} 
      />
      {showText && (
        <span className={cn(
          "font-bold text-gray-900",
          size === "sm" && "text-lg",
          size === "md" && "text-xl",
          size === "lg" && "text-2xl"
        )}>
          InvoiceGen
        </span>
      )}
    </div>
  );
}