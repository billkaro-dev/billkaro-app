import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { 
  CreditCard, 
  Wallet,
  SmartphoneNfc, 
  Link, 
  DollarSign 
} from "lucide-react";
import { paymentMethods } from "@/lib/utils";

interface PaymentMethodsProps {
  currentMethod: string;
  onChange: (method: string) => void;
}

export function PaymentMethods({ currentMethod, onChange }: PaymentMethodsProps) {
  return (
    <div>
      <RadioGroup 
        defaultValue={currentMethod}
        onValueChange={onChange}
        className="space-y-4"
      >
        <div className="flex items-center">
          <RadioGroupItem value="Bank Transfer" id="bankTransfer" />
          <Label htmlFor="bankTransfer" className="ml-3 flex items-center">
            <CreditCard className="mr-2 h-4 w-4 text-gray-600" />
            <span className="text-gray-800">Bank Transfer</span>
          </Label>
        </div>
        
        <div className="flex items-center">
          <RadioGroupItem value="PayPal" id="paypal" />
          <Label htmlFor="paypal" className="ml-3 flex items-center">
            <Wallet className="mr-2 h-4 w-4 text-gray-600" />
            <span className="text-gray-800">PayPal</span>
          </Label>
        </div>
        
        <div className="flex items-center">
          <RadioGroupItem value="UPI" id="upi" />
          <Label htmlFor="upi" className="ml-3 flex items-center">
            <SmartphoneNfc className="mr-2 h-4 w-4 text-gray-600" />
            <span className="text-gray-800">UPI</span>
          </Label>
        </div>
        
        <div className="flex items-center">
          <RadioGroupItem value="Payment Link" id="paymentLink" />
          <Label htmlFor="paymentLink" className="ml-3 flex items-center">
            <Link className="mr-2 h-4 w-4 text-gray-600" />
            <span className="text-gray-800">Payment Link</span>
          </Label>
        </div>
        
        <div className="flex items-center">
          <RadioGroupItem value="Cash" id="cash" />
          <Label htmlFor="cash" className="ml-3 flex items-center">
            <DollarSign className="mr-2 h-4 w-4 text-gray-600" />
            <span className="text-gray-800">Cash</span>
          </Label>
        </div>
      </RadioGroup>
    </div>
  );
}
