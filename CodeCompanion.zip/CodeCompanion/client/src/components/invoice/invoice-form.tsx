import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { insertInvoiceSchema, type InsertInvoice, InvoiceItem } from "@shared/schema";
import { LogoUpload } from "./logo-upload";
import { ItemsTable } from "./items-table";
import { PaymentMethods } from "./payment-methods";
import { addDays, calculateDueDateFromTerms, currencies, paymentTerms } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface InvoiceFormProps {
  onSubmit: (data: InsertInvoice) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}

export function InvoiceForm({ onSubmit, onCancel, isSubmitting }: InvoiceFormProps) {
  const [items, setItems] = useState<InvoiceItem[]>([
    { 
      id: "1", 
      description: "", 
      quantity: 1, 
      rate: 0, 
      discount: 0, 
      discountType: "%", 
      amount: 0 
    }
  ]);
  
  const [subtotal, setSubtotal] = useState(0);
  const [total, setTotal] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("Bank Transfer");

  const form = useForm<InsertInvoice>({
    resolver: zodResolver(insertInvoiceSchema),
    defaultValues: {
      number: "INV-0001",
      issueDate: format(new Date(), "MM-dd-yyyy"),
      dueDate: format(addDays(new Date(), 30), "MM-dd-yyyy"),
      currency: "USD ($)",
      paymentTerms: "NET30",
      from: "",
      to: "",
      subtotal: 0,
      discount: 0,
      discountType: "%",
      tax: 0,
      taxType: "%",
      shipping: 0,
      total: 0,
      paymentMethod: "Bank Transfer",
      paymentDetails: "",
      notes: "",
      terms: "",
      items: items,
    },
  });

  // Update issue date and due date
  const handleIssueDate = (date: Date | undefined) => {
    if (!date) return;
    
    form.setValue("issueDate", format(date, "MM-dd-yyyy"));
    
    const paymentTermsValue = form.getValues("paymentTerms");
    const dueDate = calculateDueDateFromTerms(date, paymentTermsValue);
    form.setValue("dueDate", format(dueDate, "MM-dd-yyyy"));
  };
  
  // Handle payment terms change
  const handlePaymentTerms = (terms: string) => {
    form.setValue("paymentTerms", terms);
    
    // Parse the current issue date
    const issueDateStr = form.getValues("issueDate");
    let issueDate;
    try {
      const [month, day, year] = issueDateStr.split("-").map(Number);
      issueDate = new Date(year, month - 1, day);
    } catch (e) {
      issueDate = new Date();
    }
    
    // Calculate new due date
    const dueDate = calculateDueDateFromTerms(issueDate, terms);
    form.setValue("dueDate", format(dueDate, "MM-dd-yyyy"));
  };

  // Update calculations when items change
  useEffect(() => {
    // Calculate subtotal
    const newSubtotal = items.reduce((sum, item) => {
      return sum + item.amount;
    }, 0);
    
    setSubtotal(newSubtotal);
    form.setValue("subtotal", newSubtotal);
    
    // Calculate total
    const discountValue = form.getValues("discount") || 0;
    const discountType = form.getValues("discountType") || "%";
    const taxValue = form.getValues("tax") || 0;
    const taxType = form.getValues("taxType") || "%";
    const shippingValue = form.getValues("shipping") || 0;
    
    let discountAmount = 0;
    if (discountType === "%") {
      discountAmount = (newSubtotal * discountValue) / 100;
    } else {
      discountAmount = discountValue;
    }
    
    let taxAmount = 0;
    if (taxType === "%") {
      taxAmount = ((newSubtotal - discountAmount) * taxValue) / 100;
    } else {
      taxAmount = taxValue;
    }
    
    const newTotal = newSubtotal - discountAmount + taxAmount + shippingValue;
    setTotal(newTotal);
    form.setValue("total", newTotal);
    
    // Update items in form
    form.setValue("items", items);
  }, [items, form]);

  // Recalculate when discount, tax, or shipping changes
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === "discount" || name === "discountType" || name === "tax" || name === "taxType" || name === "shipping") {
        // Calculate total
        const discountValue = form.getValues("discount") || 0;
        const discountType = form.getValues("discountType") || "%";
        const taxValue = form.getValues("tax") || 0;
        const taxType = form.getValues("taxType") || "%";
        const shippingValue = form.getValues("shipping") || 0;
        
        let discountAmount = 0;
        if (discountType === "%") {
          discountAmount = (subtotal * discountValue) / 100;
        } else {
          discountAmount = discountValue;
        }
        
        let taxAmount = 0;
        if (taxType === "%") {
          taxAmount = ((subtotal - discountAmount) * taxValue) / 100;
        } else {
          taxAmount = taxValue;
        }
        
        const newTotal = subtotal - discountAmount + taxAmount + shippingValue;
        setTotal(newTotal);
        form.setValue("total", newTotal);
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form, subtotal]);

  const handleFormSubmit = (data: InsertInvoice) => {
    // Set payment method before submission
    data.paymentMethod = paymentMethod;
    onSubmit(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-8">
        {/* Invoice Details Section */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <h2 className="text-lg font-medium text-gray-800 mb-6">Invoice Details</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Logo Upload */}
              <div className="border border-gray-200 rounded-lg p-6 flex flex-col items-center justify-center text-center">
                <LogoUpload onLogoChange={(logo) => form.setValue("logo", logo)} />
              </div>

              {/* Invoice Number & Dates */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="number"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Invoice Number</FormLabel>
                      <FormControl>
                        <Input {...field} className="w-full" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Issue Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                field.value
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={new Date(field.value)}
                            onSelect={(date) => handleIssueDate(date)}
                            disabled={(date) => date < new Date("1900-01-01")}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {currencies.map((currency) => (
                            <SelectItem key={currency.value} value={currency.value}>
                              {currency.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Payment Terms & Due Date */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="paymentTerms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment Terms</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          field.onChange(value);
                          handlePaymentTerms(value);
                        }} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select payment terms" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {paymentTerms.map((term) => (
                            <SelectItem key={term.value} value={term.value}>
                              {term.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Due Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                field.value
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={new Date(field.value)}
                            onSelect={(date) => 
                              date && form.setValue("dueDate", format(date, "MM-dd-yyyy"))
                            }
                            disabled={(date) => date < new Date("1900-01-01")}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Business Details Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Invoice From */}
          <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Invoice From</h2>
              <p className="text-sm text-gray-500 mb-3">Your Business Details</p>
              
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Business Name,
Address,
Phone,
Email,
TAX ID, etc."
                        {...field}
                        rows={5}
                        className="resize-none"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Bill To */}
          <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Bill To</h2>
              <p className="text-sm text-gray-500 mb-3">Client Details</p>
              
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Client/Business Name,
Address,
Phone,
Email,
TAX ID, etc."
                        {...field}
                        rows={5}
                        className="resize-none"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
        </div>

        {/* Line Items Section */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <h2 className="text-lg font-medium text-gray-800 mb-6">Items</h2>
            
            <ItemsTable 
              items={items} 
              currency={form.watch("currency")} 
              onItemsChange={setItems}
            />
            
            {/* Totals */}
            <div className="mt-8 md:w-1/2 md:ml-auto">
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal:</span>
                  <span className="font-medium">
                    {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: form.watch("currency").substring(0, 3),
                    }).format(subtotal)}
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">Discount:</span>
                  <div className="flex w-32">
                    <FormField
                      control={form.control}
                      name="discount"
                      render={({ field }) => (
                        <FormItem className="mb-0 flex-1">
                          <FormControl>
                            <Input 
                              type="number" 
                              min={0}
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseFloat(e.target.value) || 0);
                              }}
                              className="w-20 text-right rounded-r-none"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="discountType"
                      render={({ field }) => (
                        <FormItem className="mb-0">
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-12 rounded-l-none border-l-0">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="%">%</SelectItem>
                              <SelectItem value="$">$</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">Tax:</span>
                  <div className="flex w-32">
                    <FormField
                      control={form.control}
                      name="tax"
                      render={({ field }) => (
                        <FormItem className="mb-0 flex-1">
                          <FormControl>
                            <Input 
                              type="number" 
                              min={0}
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseFloat(e.target.value) || 0);
                              }}
                              className="w-20 text-right rounded-r-none"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="taxType"
                      render={({ field }) => (
                        <FormItem className="mb-0">
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="w-12 rounded-l-none border-l-0">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="%">%</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">Shipping:</span>
                  <FormField
                    control={form.control}
                    name="shipping"
                    render={({ field }) => (
                      <FormItem className="mb-0">
                        <FormControl>
                          <Input 
                            type="number" 
                            min={0}
                            {...field}
                            onChange={(e) => {
                              field.onChange(parseFloat(e.target.value) || 0);
                            }}
                            className="w-32 text-right"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between pt-3 border-t border-gray-200">
                  <span className="font-medium">Total:</span>
                  <span className="font-semibold text-primary text-lg">
                    {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: form.watch("currency").substring(0, 3),
                    }).format(total)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Section */}
        <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <h2 className="text-lg font-medium text-gray-800 mb-6">How does this invoice get paid?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <PaymentMethods
                currentMethod={paymentMethod}
                onChange={(method) => setPaymentMethod(method)}
              />
              
              <div>
                <div className="relative">
                  <div className="flex items-center text-sm text-primary mb-2">
                    <span className="i-lucide-info-circle mr-1"></span>
                    <span>
                      {paymentMethod === "Bank Transfer" ? "Enter bank details" :
                       paymentMethod === "PayPal" ? "Enter PayPal details" :
                       paymentMethod === "UPI" ? "Enter UPI ID" :
                       paymentMethod === "Payment Link" ? "Enter payment link" :
                       "Enter payment instructions"}
                    </span>
                  </div>
                  <FormField
                    control={form.control}
                    name="paymentDetails"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea 
                            placeholder={
                              paymentMethod === "Bank Transfer" ? 
                              "Bank Name,\nAccount Holder Name,\nAccount Number,\nAccount Type,\nIFSC/SWIFT Code,\nIBAN, etc..." :
                              paymentMethod === "PayPal" ?
                              "PayPal email address or link" :
                              paymentMethod === "UPI" ?
                              "UPI ID (e.g. name@upi)" :
                              paymentMethod === "Payment Link" ?
                              "URL for payment" :
                              "Payment instructions"
                            }
                            {...field}
                            rows={6}
                            className="resize-none"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notes And Terms Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Notes */}
          <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Notes</h2>
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Notes to be displayed on the invoice"
                        {...field}
                        rows={4}
                        className="resize-none"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Terms */}
          <Card className="bg-white rounded-lg shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Terms</h2>
              <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Terms and conditions for this invoice"
                        {...field}
                        rows={4}
                        className="resize-none"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
        </div>

        {/* Form Actions */}
        <div className="flex justify-end space-x-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button 
            type="submit"
            className="bg-gray-900 hover:bg-black"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Creating..." : "Create Invoice"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
