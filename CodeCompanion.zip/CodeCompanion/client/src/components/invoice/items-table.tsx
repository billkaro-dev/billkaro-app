import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle, Trash2 } from "lucide-react";
import { type InvoiceItem } from "@shared/schema";

interface ItemsTableProps {
  items: InvoiceItem[];
  currency: string;
  onItemsChange: (items: InvoiceItem[]) => void;
}

export function ItemsTable({ items, currency, onItemsChange }: ItemsTableProps) {
  const currencySymbol = currency.split(' ')[1]?.replace(/[()]/g, '') || '$';
  
  const calculateItemAmount = (item: InvoiceItem): number => {
    const quantity = item.quantity || 0;
    const rate = item.rate || 0;
    const discount = item.discount || 0;
    const discountType = item.discountType || '%';
    
    let discountAmount = 0;
    if (discountType === '%') {
      discountAmount = (quantity * rate * discount) / 100;
    } else {
      discountAmount = discount;
    }
    
    return quantity * rate - discountAmount;
  };
  
  const handleItemChange = (id: string, field: keyof InvoiceItem, value: any) => {
    const updatedItems = items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        updatedItem.amount = calculateItemAmount(updatedItem);
        return updatedItem;
      }
      return item;
    });
    
    onItemsChange(updatedItems);
  };
  
  const addItem = () => {
    const newItem: InvoiceItem = {
      id: uuidv4(),
      description: "",
      quantity: 1,
      rate: 0,
      discount: 0,
      discountType: "%",
      amount: 0
    };
    
    onItemsChange([...items, newItem]);
  };
  
  const removeItem = (id: string) => {
    if (items.length <= 1) return; // Keep at least one item
    const updatedItems = items.filter(item => item.id !== id);
    onItemsChange(updatedItems);
  };
  
  return (
    <div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th scope="col" className="py-3 px-3 text-left text-sm font-medium text-gray-700 w-2/5">Item Description</th>
              <th scope="col" className="py-3 px-3 text-center text-sm font-medium text-gray-700">Qty</th>
              <th scope="col" className="py-3 px-3 text-center text-sm font-medium text-gray-700">Rate</th>
              <th scope="col" className="py-3 px-3 text-center text-sm font-medium text-gray-700">Discount</th>
              <th scope="col" className="py-3 px-3 text-right text-sm font-medium text-gray-700">Amount</th>
              <th scope="col" className="py-3 px-2 text-center text-sm font-medium text-gray-700 w-8"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {items.map((item) => (
              <tr key={item.id}>
                <td className="py-2 px-3">
                  <Input
                    value={item.description}
                    onChange={(e) => handleItemChange(item.id!, 'description', e.target.value)}
                    placeholder="Item description"
                    className="w-full"
                  />
                </td>
                <td className="py-2 px-3">
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => handleItemChange(item.id!, 'quantity', parseFloat(e.target.value) || 0)}
                    min={1}
                    className="w-full text-center"
                  />
                </td>
                <td className="py-2 px-3">
                  <Input
                    type="number"
                    value={item.rate}
                    onChange={(e) => handleItemChange(item.id!, 'rate', parseFloat(e.target.value) || 0)}
                    min={0}
                    step="0.01"
                    className="w-full text-center"
                  />
                </td>
                <td className="py-2 px-3">
                  <div className="flex">
                    <Input
                      type="number"
                      value={item.discount}
                      onChange={(e) => handleItemChange(item.id!, 'discount', parseFloat(e.target.value) || 0)}
                      min={0}
                      max={item.discountType === "%" ? 100 : undefined}
                      className="w-full text-center rounded-r-none"
                    />
                    <Select
                      value={item.discountType}
                      onValueChange={(value) => handleItemChange(item.id!, 'discountType', value)}
                    >
                      <SelectTrigger className="w-16 rounded-l-none border-l-0">
                        <SelectValue placeholder="%" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="%">%</SelectItem>
                        <SelectItem value="$">{currencySymbol}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </td>
                <td className="py-2 px-3 text-right">
                  <span className="text-gray-800 font-medium">
                    {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: currency.substring(0, 3),
                    }).format(item.amount)}
                  </span>
                </td>
                <td className="py-2 px-2 text-center">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon"
                    className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => removeItem(item.id!)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="mt-4">
        <Button 
          type="button" 
          variant="link" 
          className="text-primary font-medium hover:text-primary/80"
          onClick={addItem}
        >
          <PlusCircle className="mr-2 h-4 w-4" /> Add Item
        </Button>
      </div>
    </div>
  );
}
