import { useState, useRef, ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import { toBase64 } from "@/lib/utils";
import { Upload, Plus } from "lucide-react";

interface LogoUploadProps {
  onLogoChange: (logo: string) => void;
}

export function LogoUpload({ onLogoChange }: LogoUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (!file) return;
    
    // Check file size (1MB = 1048576 bytes)
    if (file.size > 1048576) {
      setError("File size exceeds 1MB limit");
      return;
    }
    
    // Check file type
    const validTypes = ["image/jpeg", "image/png", "image/svg+xml"];
    if (!validTypes.includes(file.type)) {
      setError("Only JPG, PNG, and SVG files are supported");
      return;
    }
    
    try {
      const base64 = await toBase64(file);
      setPreview(base64);
      onLogoChange(base64);
      setError(null);
    } catch (err) {
      setError("Error processing file");
      console.error(err);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center text-center">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".jpg,.jpeg,.png,.svg"
        className="hidden"
      />
      
      <div 
        className="w-20 h-20 border-2 border-gray-300 border-dashed rounded-lg flex items-center justify-center mb-3 bg-gray-50 text-gray-400 overflow-hidden"
        onClick={handleUploadClick}
      >
        {preview ? (
          <img src={preview} alt="Logo preview" className="w-full h-full object-contain" />
        ) : (
          <Plus className="h-8 w-8 text-gray-400" />
        )}
      </div>
      
      <p className="text-gray-700 font-medium">Upload logo</p>
      <p className="text-xs text-gray-500 mt-1">Supported formats: JPG, PNG, SVG</p>
      <p className="text-xs text-gray-500">Recommended size: 500px × 500px</p>
      
      <Button 
        type="button" 
        variant="secondary" 
        className="mt-4 bg-amber-500 hover:bg-amber-600 text-white"
        onClick={handleUploadClick}
      >
        <Upload className="mr-2 h-4 w-4" />
        Upload
      </Button>
      
      {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
      <p className="text-xs text-gray-500 mt-3">Max upload size: 1 MB</p>
    </div>
  );
}
