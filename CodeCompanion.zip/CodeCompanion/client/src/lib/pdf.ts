import { Invoice, InvoiceItem } from "@shared/schema";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import { format } from "date-fns";

// Add autotable to jsPDF
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export const generatePDF = async (invoice: Invoice): Promise<void> => {
  const doc = new jsPDF();
  const items = invoice.items as unknown as InvoiceItem[];
  const currency = invoice.currency.split(" ")[1]?.replace(/[()]/g, "") || "$";
  
  // Set document properties
  doc.setProperties({
    title: `Invoice ${invoice.number}`,
    subject: `Invoice for ${invoice.to.split('\n')[0]}`,
    author: invoice.from.split('\n')[0],
    keywords: 'invoice, billing',
    creator: 'Invoice Generator'
  });
  
  // Add logo if available
  if (invoice.logo) {
    try {
      doc.addImage(invoice.logo, 'JPEG', 10, 10, 40, 40);
    } catch (error) {
      console.error("Error adding logo to PDF:", error);
    }
  }
  
  // Add title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('INVOICE', 200, 20, { align: 'right' });
  
  // Add invoice details
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Invoice Number: ${invoice.number}`, 200, 30, { align: 'right' });
  doc.text(`Issue Date: ${invoice.issueDate}`, 200, 35, { align: 'right' });
  doc.text(`Due Date: ${invoice.dueDate}`, 200, 40, { align: 'right' });
  
  // Add from and to sections
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('From:', 10, 60);
  doc.text('To:', 120, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  // Handle multiline text
  const fromLines = invoice.from.split('\n');
  const toLines = invoice.to.split('\n');
  
  let yPos = 65;
  fromLines.forEach(line => {
    doc.text(line, 10, yPos);
    yPos += 5;
  });
  
  yPos = 65;
  toLines.forEach(line => {
    doc.text(line, 120, yPos);
    yPos += 5;
  });
  
  // Add items table
  const tableColumn = ["Item", "Qty", "Rate", "Discount", "Amount"];
  const tableRows = items.map(item => [
    item.description,
    item.quantity.toString(),
    `${currency}${item.rate.toFixed(2)}`,
    item.discount > 0 ? `${item.discount}${item.discountType}` : "-",
    `${currency}${item.amount.toFixed(2)}`
  ]);
  
  doc.autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: 100,
    theme: 'grid',
    styles: { fontSize: 9 },
    headStyles: { fillColor: [66, 139, 202] },
  });
  
  // Add totals
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  doc.setFontSize(10);
  
  doc.text(`Subtotal:`, 140, finalY);
  doc.text(`${currency}${Number(invoice.subtotal).toFixed(2)}`, 190, finalY, { align: 'right' });
  
  if (invoice.discount > 0) {
    doc.text(`Discount (${invoice.discountType}):`, 140, finalY + 5);
    doc.text(`${currency}${Number(invoice.discount).toFixed(2)}`, 190, finalY + 5, { align: 'right' });
  }
  
  if (invoice.tax > 0) {
    doc.text(`Tax (${invoice.taxType}):`, 140, finalY + 10);
    doc.text(`${currency}${(Number(invoice.subtotal) * Number(invoice.tax) / 100).toFixed(2)}`, 190, finalY + 10, { align: 'right' });
  }
  
  if (invoice.shipping > 0) {
    doc.text(`Shipping:`, 140, finalY + 15);
    doc.text(`${currency}${Number(invoice.shipping).toFixed(2)}`, 190, finalY + 15, { align: 'right' });
  }
  
  // Total
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total:`, 140, finalY + 25);
  doc.text(`${currency}${Number(invoice.total).toFixed(2)}`, 190, finalY + 25, { align: 'right' });
  
  // Payment information
  doc.setFontSize(11);
  doc.text(`Payment Method: ${invoice.paymentMethod}`, 10, finalY + 40);
  
  if (invoice.paymentDetails) {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const detailsLines = invoice.paymentDetails.split('\n');
    let detailsY = finalY + 45;
    
    detailsLines.forEach(line => {
      doc.text(line, 10, detailsY);
      detailsY += 5;
    });
  }
  
  // Notes & Terms
  if (invoice.notes || invoice.terms) {
    let notesY = finalY + 70;
    
    if (invoice.notes) {
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.text('Notes:', 10, notesY);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      const notesLines = invoice.notes.split('\n');
      notesY += 5;
      
      notesLines.forEach(line => {
        doc.text(line, 10, notesY);
        notesY += 5;
      });
    }
    
    if (invoice.terms) {
      notesY += 5;
      doc.setFontSize(11);
      doc.setFont('helvetica', 'bold');
      doc.text('Terms and Conditions:', 10, notesY);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      const termsLines = invoice.terms.split('\n');
      notesY += 5;
      
      termsLines.forEach(line => {
        doc.text(line, 10, notesY);
        notesY += 5;
      });
    }
  }
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(
      `Generated on ${format(new Date(), 'yyyy-MM-dd')} | Page ${i} of ${pageCount}`,
      doc.internal.pageSize.getWidth() / 2, 
      doc.internal.pageSize.getHeight() - 10, 
      { align: 'center' }
    );
  }
  
  // Save the PDF
  doc.save(`Invoice_${invoice.number}.pdf`);
};
