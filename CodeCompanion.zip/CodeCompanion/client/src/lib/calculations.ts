import { InvoiceItem } from "@shared/schema";

export const calculateLineItemAmount = (item: InvoiceItem): number => {
  const quantity = item.quantity || 0;
  const rate = item.rate || 0;
  const discount = item.discount || 0;
  const discountType = item.discountType || '%';
  
  let discountAmount = 0;
  if (discountType === '%') {
    discountAmount = (quantity * rate * discount) / 100;
  } else {
    discountAmount = discount;
  }
  
  return quantity * rate - discountAmount;
};

export const calculateSubtotal = (items: InvoiceItem[]): number => {
  return items.reduce((sum, item) => sum + (item.amount || 0), 0);
};

export const calculateDiscountAmount = (subtotal: number, discount: number, discountType: string): number => {
  if (discountType === '%') {
    return (subtotal * discount) / 100;
  }
  return discount;
};

export const calculateTaxAmount = (subtotal: number, discountAmount: number, tax: number, taxType: string): number => {
  if (taxType === '%') {
    return ((subtotal - discountAmount) * tax) / 100;
  }
  return tax;
};

export const calculateTotal = (
  subtotal: number, 
  discountAmount: number, 
  taxAmount: number, 
  shipping: number
): number => {
  return subtotal - discountAmount + taxAmount + shipping;
};
