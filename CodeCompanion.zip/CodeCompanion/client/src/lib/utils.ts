import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency = "USD"): string {
  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency.substring(0, 3),
    minimumFractionDigits: 2,
  });
  
  return formatter.format(amount);
}

export function getNextInvoiceNumber(lastNumber: string): string {
  if (!lastNumber || !lastNumber.includes("-")) {
    return "INV-0001";
  }
  
  const parts = lastNumber.split("-");
  const numberPart = parts[1];
  
  if (!numberPart || isNaN(parseInt(numberPart))) {
    return "INV-0001";
  }
  
  const nextNumber = parseInt(numberPart) + 1;
  return `INV-${nextNumber.toString().padStart(4, "0")}`;
}

export function formatDateForInput(date: Date): string {
  return date.toISOString().substring(0, 10);
}

export function addDays(date: Date, days: number): Date {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

export const calculateDueDateFromTerms = (issueDate: Date, terms: string): Date => {
  const daysMap: Record<string, number> = {
    "NET30": 30,
    "NET15": 15,
    "NET7": 7,
    "Due on Receipt": 0,
    "Custom": 0,
  };
  
  const days = daysMap[terms] || 0;
  return addDays(issueDate, days);
};

export async function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
}

export const currencies = [
  { label: "USD ($)", value: "USD ($)" },
  { label: "EUR (€)", value: "EUR (€)" },
  { label: "GBP (£)", value: "GBP (£)" },
  { label: "JPY (¥)", value: "JPY (¥)" },
  { label: "INR (₹)", value: "INR (₹)" },
  { label: "CAD ($)", value: "CAD ($)" },
  { label: "AUD ($)", value: "AUD ($)" },
  { label: "CNY (¥)", value: "CNY (¥)" },
];

export const paymentTerms = [
  { label: "NET30 (30 days)", value: "NET30" },
  { label: "NET15 (15 days)", value: "NET15" },
  { label: "NET7 (7 days)", value: "NET7" },
  { label: "Due on Receipt", value: "Due on Receipt" },
  { label: "Custom", value: "Custom" },
];

export const paymentMethods = [
  { label: "Bank Transfer", value: "Bank Transfer", icon: "university" },
  { label: "PayPal", value: "PayPal", icon: "paypal" },
  { label: "UPI", value: "UPI", icon: "mobile-alt" },
  { label: "Payment Link", value: "Payment Link", icon: "link" },
  { label: "Cash", value: "Cash", icon: "money-bill-wave" },
];
