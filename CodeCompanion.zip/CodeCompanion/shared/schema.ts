import { pgTable, text, serial, integer, boolean, jsonb, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Invoice Schema
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  number: text("number").notNull(),
  issueDate: text("issue_date").notNull(),
  dueDate: text("due_date").notNull(),
  currency: text("currency").notNull().default("USD ($)"),
  paymentTerms: text("payment_terms").notNull().default("NET30"),
  from: text("from").notNull(),
  to: text("to").notNull(),
  logo: text("logo"),
  subtotal: numeric("subtotal").notNull().default("0"),
  discount: numeric("discount").notNull().default("0"),
  discountType: text("discount_type").notNull().default("%"),
  tax: numeric("tax").notNull().default("0"),
  taxType: text("tax_type").notNull().default("%"),
  shipping: numeric("shipping").notNull().default("0"),
  total: numeric("total").notNull().default("0"),
  paymentMethod: text("payment_method").notNull().default("Bank Transfer"),
  paymentDetails: text("payment_details"),
  notes: text("notes"),
  terms: text("terms"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  items: jsonb("items").notNull().default([]),
});

export const invoiceItemSchema = z.object({
  id: z.string().optional(),
  description: z.string().min(1, "Description is required"),
  quantity: z.number().min(1, "Quantity must be at least 1"),
  rate: z.number().min(0, "Rate cannot be negative"),
  discount: z.number().min(0, "Discount cannot be negative").max(100, "Discount cannot exceed 100%"),
  discountType: z.enum(["%", "$"]),
  amount: z.number(),
});

export type InvoiceItem = z.infer<typeof invoiceItemSchema>;

export const insertInvoiceSchema = createInsertSchema(invoices)
  .extend({
    items: z.array(invoiceItemSchema),
  })
  .omit({ id: true, createdAt: true });

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;
